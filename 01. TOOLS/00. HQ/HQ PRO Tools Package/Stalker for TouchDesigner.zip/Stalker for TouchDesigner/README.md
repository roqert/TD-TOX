# Overview
Stalker includes one project file and one TOX component. The Stalker_master.toe is a project file that monitors and receives heartbeat messages from all of the Stalker_slave.tox components on the computer.

Stalker_master.toe is expecting to receive a heartbeat message from every Stalker_slave.tox every 30 seconds. 

If 3 heartbeat messages are missed (1.5 minutes of not working) by a Stalker_slave.tox, then Stalker_master.toe will close the process and open a new version.

# How to get started
You should start off by filling in all of the settings parameters listed on the Stalker_master component. This includes:

1. Your SendGrid API Key (see below how to register one)
2. The email address you want the notifications to be from
3. The email address you want to send notifications to
4. The subject of the email
5. The body of the email

# How to register with SendGrid for email notifications
Stalker uses SendGrid for email notifications. It only takes a few minutes to make an account and it has a free tier plan that allows for free email notifications that are much more secure than using SMTP (you won't need to leave your email and password lying around). 

You can create an account by going to https://sendgrid.com and click the "Try for Free" button on the first page. 

Go through the signup, create an API key, and paste it into the SendGrid API Key custom parameter on the Stalker_master component.

# Project setup
When you've entered all the parameters of the Stalker_master component, you should move Stalker_master.toe to your project folder and not add anything else to that project. 

Stalker_master.toe will monitor the other processes that are doing heavier work. Then you should put a Stalker_slave.tox component into each of your projects running on the computer and save them. 

Once you have all the projects saved, you should open the Stalker_master project first and then after it is finished opening you should open all of your other projects that have the Stalker_slave.tox in them. 

Stalker_master.toe uses network communication to automatically communicate and perform hand shakes with each of the Stalker_slave.tox files, so no further setup is needed by you.

Alternatively you can use the built in project launcher (instructions at the end of the readme).

# How to use the logs
The Stalker components have a simple extension that allows you to log messages from all the processes into a combined log file. 

The logs are timestamped and serialized as JSON messages on every new line of the log file. 

You can read through them manually or parse them however you want by adding every new line to an array and parsing the whole array as a JSON object.

To use the extensions, you can use the global shortcut op.Stalker.Log('Your message to log here') from either the Master component or the slave tox files.  Both will route their messages to a unified log.

# How to send emails
Emails are automatically sent when heartbeats are missed by projects with Stalker_slave.tox in them and when those projects need to be restarted.

You can program and send your own custom emails as well by using the available extension with the global shortcut op.Stalker.Sendemail('Your email message here') from either the Stalker master or slave tox files.

# macOS notes
On macOS, it is difficult to launch multiple TouchDesigner projects, so a project launcher is included that can launch up to 4 projects for you. See the instructions below.

# Project launcher
A simple project launcher is included in the project that can launch up to 4 slave processes after it has finished booting (mostly made for macOS users). To use it, follow the steps below:

1. Enter the path of each project into the parameters named "Project1", "Project2", "Project3", and "Project4" parameters
2. Turn the "Auto-launch Instances" toggle on
3. Save the Stalker_master.toe project
4. Restart the project and wait 15 seconds for the slave processes to start launching

# Crash logs
When a TouchDesigner process with the Stalker_slave.tox inside of it crashes, there will be a separate log file with the word "CRASH" in front of it. It will include:

1. The name of the project that crashed in the filename
2. The date and time that the project crashed in the filename
3. A localized set of logs that include the logs only from that project

# Important notes
Make sure you keep your numbered project file next to your unnumbered project file for Stalker to be able to launch them. 

For example, "ProjectTest.15.toe" should be in the same folder as "ProjectTest.toe", otherwise you will get an error when the Stalker_master.toe tries to relaunch the slave processes after an error.

Also do not place a Stalker_slave.tox inside of the Stalker_master.toe. This may cause instability in the Stalker_master.toe. 